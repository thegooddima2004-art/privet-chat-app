# Круг — Android APK

Это Android-обёртка над веб-приложением «Круг».

- Открывает: https://privet-chat-app.lovable.app/
- Включены JavaScript и DOM Storage для авторизации Supabase.
- Запрашивается разрешение на микрофон для голосовых сообщений.
- Ссылки внутри Lovable/Supabase остаются в приложении, внешние открываются браузером.
- GitHub Actions автоматически собирает debug APK.

## Сборка

### Android Studio
Открой эту папку в Android Studio и запусти `assembleDebug`.

### GitHub
Загрузи содержимое проекта в репозиторий и запусти **Actions → Build Android APK → Run workflow**. APK появится в артефактах workflow.

> Это именно WebView-версия: серверная часть и данные остаются на существующем Lovable/Supabase. Поэтому изменения веб-приложения обновляются в Android-приложении без выпуска нового APK.
